package app.iosbanners

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.PathInterpolator
import kotlin.math.abs

/**
 * Desenha o cartão como uma janela de sobreposição (TYPE_APPLICATION_OVERLAY) no topo da tela.
 * Só aparece com a tela ligada e desbloqueada. NÃO é integração com o AOD.
 */
class BannerOverlay(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var view: NotificationCardView? = null
    private var currentData: CardData? = null
    private var removing = false
    private val dismissRunnable = Runnable { dismiss() }
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    companion object {
        private const val TAG = "IosBanners"
        private const val DISPLAY_MS = 5000L
    }

    fun canDraw(): Boolean = Settings.canDrawOverlays(ctx)

    /** Retorna true se o cartão foi realmente adicionado à tela. */
    fun show(data: CardData): Boolean {
        if (!canDraw()) return false
        return try {
            showInternal(data)
        } catch (e: Exception) {
            Log.w(TAG, "Falha ao mostrar o banner", e)
            false
        }
    }

    private fun showInternal(data: CardData): Boolean {
        val dark = Prefs.darkCard(ctx)
        val useBlur = Prefs.blur(ctx)

        // Mesma notificação (ex.: nova mensagem da mesma conversa): atualiza o cartão que já está
        // na tela, sem criar outro nem repetir a animação de entrada.
        val existing = view
        if (existing != null && !removing && currentData?.key == data.key) {
            existing.bind(data, dark, useBlur)
            currentData = data
            scheduleDismiss()
            return true
        }

        removeNow()

        val card = NotificationCardView(ctx)
        card.bind(data, dark, useBlur)

        val margin = ctx.dp(8)
        val width = ctx.resources.displayMetrics.widthPixels - margin * 2
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        val lp = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        // Mesma conta usada pelo cartão da tela bloqueada (veja bannerTopOffset em Ui.kt).
        lp.y = ctx.bannerTopOffset()

        if (useBlur && Build.VERSION.SDK_INT >= 31 && wm.isCrossWindowBlurEnabled) {
            // Experimental: o desfoque cobre o retângulo da janela (cantos podem aparecer retos).
            flags = flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.flags = flags
            lp.blurBehindRadius = ctx.dp(28)
        }

        // Estado inicial da animação de entrada (aplicado antes de anexar à janela).
        card.alpha = 0f
        card.translationY = -ctx.dp(70).toFloat()
        card.scaleX = 0.95f
        card.scaleY = 0.95f

        card.setOnTouchListener(SwipeListener())
        wm.addView(card, lp)
        view = card
        currentData = data
        removing = false

        card.post {
            card.animate()
                .alpha(1f)
                .translationY(0f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(420)
                .setInterpolator(PathInterpolator(0.2f, 0.9f, 0.2f, 1f))
                .start()
        }
        scheduleDismiss()
        return true
    }

    private inner class SwipeListener : View.OnTouchListener {
        private var downY = 0f

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = e.rawY
                    handler.removeCallbacks(dismissRunnable)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = e.rawY - downY
                    if (dy < 0f) v.translationY = dy
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    val dy = e.rawY - downY
                    if (dy < -ctx.dp(36)) {
                        dismiss()
                    } else if (abs(dy) < slop) {
                        // Usa os dados atuais: o cartão pode ter sido atualizado no lugar.
                        currentData?.let { openSource(ctx, it) }
                        dismiss()
                    } else {
                        v.animate().translationY(0f).setDuration(150).start()
                        scheduleDismiss()
                    }
                    return true
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.animate().translationY(0f).setDuration(150).start()
                    scheduleDismiss()
                    return true
                }
            }
            return false
        }
    }

    private fun scheduleDismiss() {
        handler.removeCallbacks(dismissRunnable)
        handler.postDelayed(dismissRunnable, DISPLAY_MS)
    }

    fun dismiss() {
        val v = view ?: return
        if (removing) return
        removing = true
        handler.removeCallbacks(dismissRunnable)
        v.animate()
            .translationY(-(v.height + ctx.dp(20)).toFloat())
            .alpha(0f)
            .setDuration(260)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction { removeNow() }
            .start()
    }

    private fun removeNow() {
        handler.removeCallbacks(dismissRunnable)
        val v = view
        if (v != null) {
            v.animate().cancel()
            try {
                wm.removeViewImmediate(v)
            } catch (e: Exception) {
                Log.w(TAG, "removeView falhou", e)
            }
        }
        view = null
        currentData = null
        removing = false
    }

    fun release() {
        removeNow()
    }
}
