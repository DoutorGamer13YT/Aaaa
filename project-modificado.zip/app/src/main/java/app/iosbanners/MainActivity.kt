package app.iosbanners

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.view.WindowManager

class MainActivity : Activity() {

    private companion object {
        const val REQ_POST_NOTIFICATIONS = 10
        const val CHANNEL_TEST = "ios_banners_test"
        val CARD_BG = Color.rgb(28, 28, 30)
        val TEXT_2 = Color.argb(170, 235, 235, 245)
        val ACCENT = Color.rgb(10, 132, 255)
        val GRAY_BTN = Color.rgb(58, 58, 60)
        val GOOD = Color.rgb(48, 209, 88)
        val BAD = Color.rgb(255, 69, 58)
    }

    private var binding = false

    private lateinit var masterSwitch: Switch
    private lateinit var darkSwitch: Switch
    private lateinit var blurSwitch: Switch
    private lateinit var hideSwitch: Switch
    private lateinit var lockSwitch: Switch
    private lateinit var accessStatus: TextView
    private lateinit var overlayStatus: TextView
    private lateinit var appsCount: TextView
    private lateinit var previewHolder: FrameLayout
    private lateinit var diagView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(24), dp(16), dp(32))
        scroll.addView(col)
        setContentView(scroll)

        text(col, "iOS Banners", 28f, Color.WHITE, bold = true)
        text(col, "Cartão de notificação em estilo iOS para as notificações reais do Android.", 14f, TEXT_2)
            .setPadding(0, dp(4), 0, dp(16))
        creditBadge(col)

        // --- Recurso e permissões ---
        val c1 = section(col, "Recurso e permissões")
        masterSwitch = switchRow(c1, "Ativar banners estilo iOS", null) {
            Prefs.setEnabled(this, it)
            if (it) rebindListenerIfNeeded()
        }
        accessStatus = text(c1, "", 14f, Color.WHITE)
        accessStatus.setPadding(0, dp(10), 0, 0)
        button(c1, "Conceder acesso às notificações", true) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        text(
            c1,
            "Se o Android bloquear (\"configuração restrita\"), abra \"Informações do app\" abaixo, " +
                "toque nos três pontos e escolha \"Permitir configurações restritas\".",
            12.5f, TEXT_2
        ).setPadding(0, dp(6), 0, 0)
        overlayStatus = text(c1, "", 14f, Color.WHITE)
        overlayStatus.setPadding(0, dp(12), 0, 0)
        button(c1, "Permitir exibir sobre outros apps", true) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }

        // --- Aparência e opções ---
        val c2 = section(col, "Aparência e opções")
        darkSwitch = switchRow(c2, "Cartão escuro (AMOLED)", "Desligado = cartão claro.") {
            Prefs.setDarkCard(this, it)
            refreshPreview()
        }
        blurSwitch = switchRow(
            c2, "Desfoque do fundo (experimental)",
            "Usa o desfoque do sistema quando disponível; pode cobrir a janela inteira em vez do cartão arredondado."
        ) {
            Prefs.setBlur(this, it)
            refreshPreview()
        }
        hideSwitch = switchRow(
            c2, "Remover a notificação original",
            "Evita duplicar: fica só o cartão estilo iOS. Só remove depois que o cartão apareceu na tela; " +
                "a original deixa de existir na central de notificações e podem sumir as respostas rápidas " +
                "do app de origem. Notificações de serviço/ongoing e de apps não marcados nunca são removidas. " +
                "O pop-up do sistema pode piscar por um instante antes de sumir; para evitar, desligue o pop-up " +
                "do app em Configurações → Notificações."
        ) { Prefs.setHideOriginal(this, it) }
        lockSwitch = switchRow(
            c2, "Só o cartão com a tela apagada (experimental)",
            "Se a notificação chegar com a tela apagada, ela acende bem fraca, sem relógio nem barras, " +
                "só com o cartão sobre fundo preto, na mesma posição do banner. NÃO é o AOD: a tela fica ligada " +
                "por até 12 s (ou até o tempo limite do sistema). Não verificado em aparelho."
        ) { Prefs.setLockCard(this, it) }

        // --- Apps ---
        val c3 = section(col, "Aplicativos monitorados")
        appsCount = text(c3, "", 14f, Color.WHITE)
        button(c3, "Escolher aplicativos", true) {
            startActivity(Intent(this, AppPickerActivity::class.java))
        }

        // --- Prévia ---
        val c4 = section(col, "Prévia")
        text(c4, "Exemplo de layout (não é uma notificação real).", 12.5f, TEXT_2)
            .setPadding(0, 0, 0, dp(10))
        previewHolder = FrameLayout(this)
        c4.addView(previewHolder)

        // --- Teste ---
        val c5 = section(col, "Teste")
        button(c5, "Enviar notificação de teste", true) { sendTest() }
        text(
            c5,
            "O app envia uma notificação real de si mesmo; o serviço a recebe como qualquer outra. " +
                "Mantenha o celular desbloqueado para ver o cartão.",
            12.5f, TEXT_2
        ).setPadding(0, dp(6), 0, 0)

        // --- Diagnóstico ---
        val c6 = section(col, "Diagnóstico")
        diagView = text(c6, "", 13f, Color.WHITE)
        diagView.typeface = Typeface.MONOSPACE
        button(c6, "Informações do app (configurações restritas)", false) {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        }
        button(c6, "Ajustar uso de bateria", false) { openBatterySettings() }
        text(
            c6,
            "Para o serviço não ser suspenso: permita \"Sem restrição\" aqui e, na Samsung, confira em " +
                "Configurações → Bateria → Limites de uso em segundo plano (os nomes variam conforme a One UI) " +
                "se o app não está em \"Apps em suspensão\"/\"suspensão profunda\". " +
                "O app não usa serviço em primeiro plano nem tarefas periódicas: só trabalha quando chega uma notificação.",
            12.5f, TEXT_2
        ).setPadding(0, dp(6), 0, 0)

        // --- AOD ---
        val c7 = section(col, "Sobre o Always On Display (AOD)")
        text(
            c7,
            "O AOD da Samsung é desenhado pelo próprio sistema e só mostra os ícones das notificações não lidas. " +
                "Não existe API pública do Android nem da One UI para um app mudar a aparência disso, " +
                "então este app NÃO altera o AOD nativo.\n\n" +
                "O que ele faz: (1) mostra o cartão estilo iOS por cima do que estiver na tela, com o celular " +
                "ligado e desbloqueado; (2) com a tela apagada, acende a tela bem fraca só com o cartão sobre " +
                "fundo preto (no AMOLED o preto fica apagado). Essa segunda opção é uma tela comum do app, " +
                "não o AOD: a tela de fato liga até o tempo limite do sistema. Não foi verificada em aparelho.",
            13.5f, Color.WHITE
        )
    }

    override fun onResume() {
        super.onResume()
        rebindListenerIfNeeded()
        refresh()
    }

    /** Se o acesso foi concedido mas o serviço está desconectado, pede ao sistema que o vincule de novo. */
    private fun rebindListenerIfNeeded() {
        if (listenerGranted() && !NotificationService.connected) {
            try {
                NotificationListenerService.requestRebind(
                    ComponentName(this, NotificationService::class.java)
                )
            } catch (e: Exception) {
                // Sem ação: o diagnóstico mostra o estado real.
            }
        }
    }

    /** Pede "Sem restrição de bateria" direto; se o sistema não permitir, abre a lista de otimização. */
    private fun openBatterySettings() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm != null && !pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
                return
            } catch (e: Exception) {
                // Cai para a lista de otimização de bateria.
            }
        }
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (e: Exception) {
            toast("Abra Configurações → Bateria e deixe este app sem restrição.")
        }
    }

    private fun refresh() {
        binding = true
        masterSwitch.isChecked = Prefs.enabled(this)
        darkSwitch.isChecked = Prefs.darkCard(this)
        blurSwitch.isChecked = Prefs.blur(this)
        hideSwitch.isChecked = Prefs.hideOriginal(this)
        lockSwitch.isChecked = Prefs.lockCard(this)
        binding = false

        val access = listenerGranted()
        accessStatus.text = if (access) "Acesso às notificações: ativo" else "Acesso às notificações: inativo"
        accessStatus.setTextColor(if (access) GOOD else BAD)
        val overlay = Settings.canDrawOverlays(this)
        overlayStatus.text = if (overlay) "Exibir sobre outros apps: permitido" else "Exibir sobre outros apps: não permitido"
        overlayStatus.setTextColor(if (overlay) GOOD else BAD)

        appsCount.text = "${Prefs.monitoredApps(this).size} aplicativo(s) monitorado(s)"
        diagView.text = diagnostics()
        refreshPreview()
    }

    private fun refreshPreview() {
        previewHolder.removeAllViews()
        val icon: Drawable? = try {
            packageManager.getApplicationIcon(packageName)
        } catch (e: Exception) {
            null
        }
        val sample = CardData(
            key = "preview",
            packageName = packageName,
            appName = "App",
            title = "Remetente",
            body = "Prévia do conteúdo da mensagem, em até duas linhas de texto.",
            appIcon = icon,
            avatar = null,
            contentIntent = null,
            postTime = 0L
        )
        val card = NotificationCardView(this)
        card.bind(sample, Prefs.darkCard(this), false)
        previewHolder.addView(
            card,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
    }

    // ---------- Teste ----------

    private fun sendTest() {
        if (!Prefs.enabled(this)) {
            toast("Ative \"Ativar banners estilo iOS\" primeiro.")
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_POST_NOTIFICATIONS)
            return
        }
        postTest()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_POST_NOTIFICATIONS &&
            grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            postTest()
        }
        refresh()
    }

    private fun postTest() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_TEST, "Teste", NotificationManager.IMPORTANCE_HIGH)
        )
        val tap = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val extras = Bundle()
        extras.putBoolean(NotificationService.EXTRA_IS_TEST, true)
        val n = Notification.Builder(this, CHANNEL_TEST)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("Teste do iOS Banners")
            .setContentText("Notificação de teste enviada pelo próprio app.")
            .setContentIntent(tap)
            .setAutoCancel(true)
            .addExtras(extras)
            .build()
        nm.notify(1001, n)
        toast("Teste enviado. Mantenha o celular desbloqueado.")
    }

    // ---------- Diagnóstico ----------

    private fun listenerGranted(): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        return nm.isNotificationListenerAccessGranted(ComponentName(this, NotificationService::class.java))
    }

    private fun yn(v: Boolean): String = if (v) "sim" else "não"

    private fun oneUiVersion(): String? {
        return try {
            val f = Build.VERSION::class.java.getDeclaredField("SEM_PLATFORM_INT")
            val v = f.getInt(null)
            if (v < 90000) {
                null
            } else {
                val d = v - 90000
                "${d / 10000}.${(d % 10000) / 100}"
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun aodState(): String {
        return try {
            when (Settings.System.getString(contentResolver, "aod_mode")) {
                null -> "não detectado"
                "1" -> "ativado"
                else -> "desativado"
            }
        } catch (e: Exception) {
            "não detectado"
        }
    }

    private fun diagnostics(): String {
        val sb = StringBuilder()
        fun line(k: String, v: String) {
            sb.append(k).append(": ").append(v).append('\n')
        }
        val isA54 = Build.MODEL.startsWith("SM-A546")
        line(
            "Aparelho",
            "${Build.MANUFACTURER} ${Build.MODEL}" + if (isA54) " (Galaxy A54 5G)" else " (não é o A54 5G)"
        )
        line("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        line("One UI", oneUiVersion() ?: "não detectada")
        line("Acesso às notificações", yn(listenerGranted()))
        line("Serviço conectado", yn(NotificationService.connected))
        line("Exibir sobre outros apps", yn(Settings.canDrawOverlays(this)))
        if (Build.VERSION.SDK_INT >= 33) {
            line(
                "Notificações do app (teste)",
                yn(checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
            )
        }
        val pm = getSystemService(PowerManager::class.java)
        line("Sem restrição de bateria", yn(pm.isIgnoringBatteryOptimizations(packageName)))
        val wm = getSystemService(WindowManager::class.java)
        val blur = Build.VERSION.SDK_INT >= 31 && wm.isCrossWindowBlurEnabled
        line("Desfoque do sistema", yn(blur))
        line("AOD do sistema (leitura aprox.)", aodState())
        line("Integração com o AOD", "não suportada")
        return sb.toString().trimEnd()
    }

    // ---------- Helpers de interface ----------

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = dp(radiusDp).toFloat()
        g.setColor(color)
        return g
    }

    /** Crédito do desenvolvedor: alto contraste (branco sobre fundo escuro) e destacado por borda azul. */
    private fun creditBadge(parent: LinearLayout) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        val bg = rounded(CARD_BG, 16)
        bg.setStroke(dp(2), ACCENT)
        box.background = bg
        box.setPadding(dp(16), dp(12), dp(16), dp(12))
        text(box, "Desenvolvido por", 13f, TEXT_2).gravity = Gravity.CENTER
        text(box, CREDIT_HANDLE, 22f, Color.WHITE, bold = true).gravity = Gravity.CENTER
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(16)
        parent.addView(box, lp)
    }

    private fun section(parent: LinearLayout, title: String): LinearLayout {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = rounded(CARD_BG, 18)
        card.setPadding(dp(16), dp(14), dp(16), dp(16))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(12)
        parent.addView(card, lp)
        text(card, title, 17f, Color.WHITE, bold = true).setPadding(0, 0, 0, dp(8))
        return card
    }

    private fun text(
        parent: LinearLayout,
        value: String,
        sp: Float,
        color: Int,
        bold: Boolean = false
    ): TextView {
        val t = TextView(this)
        t.text = value
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        if (bold) t.paint.isFakeBoldText = true
        parent.addView(
            t,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        return t
    }

    private fun button(parent: LinearLayout, label: String, primary: Boolean, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.background = rounded(if (primary) ACCENT else GRAY_BTN, 12)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46))
        lp.topMargin = dp(8)
        parent.addView(b, lp)
        return b
    }

    private fun switchRow(
        parent: LinearLayout,
        label: String,
        hint: String?,
        onChange: (Boolean) -> Unit
    ): Switch {
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.setPadding(0, dp(6), 0, dp(6))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val t = TextView(this)
        t.text = label
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
        t.setTextColor(Color.WHITE)
        row.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this)
        sw.setOnCheckedChangeListener { _, isChecked -> if (!binding) onChange(isChecked) }
        row.addView(sw)
        wrap.addView(row)
        if (hint != null) {
            val h = TextView(this)
            h.text = hint
            h.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            h.setTextColor(TEXT_2)
            wrap.addView(h)
        }
        parent.addView(
            wrap,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        return sw
    }
}
