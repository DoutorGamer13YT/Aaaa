package app.iosbanners

import android.content.Context
import android.content.SharedPreferences

/** Configurações persistentes (SharedPreferences privado do app). */
object Prefs {
    private const val FILE = "ios_banners_prefs"
    private const val K_ENABLED = "enabled"
    private const val K_DARK = "dark_card"
    private const val K_HIDE_ORIGINAL = "hide_original"
    private const val K_BLUR = "blur"
    private const val K_LOCK_CARD = "lock_card"
    private const val K_APPS = "monitored_apps"

    /** Apps pré-selecionados na primeira execução. */
    val DEFAULT_APPS: Set<String> = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b",
        "com.instagram.android",
        "com.discord"
    )

    private fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun enabled(c: Context): Boolean = sp(c).getBoolean(K_ENABLED, false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean(K_ENABLED, v).apply()

    fun darkCard(c: Context): Boolean = sp(c).getBoolean(K_DARK, true)
    fun setDarkCard(c: Context, v: Boolean) = sp(c).edit().putBoolean(K_DARK, v).apply()

    /** Ligado por padrão: evita a notificação duplicada (original + cartão estilo iOS). */
    fun hideOriginal(c: Context): Boolean = sp(c).getBoolean(K_HIDE_ORIGINAL, true)
    fun setHideOriginal(c: Context, v: Boolean) = sp(c).edit().putBoolean(K_HIDE_ORIGINAL, v).apply()

    fun blur(c: Context): Boolean = sp(c).getBoolean(K_BLUR, false)
    fun setBlur(c: Context, v: Boolean) = sp(c).edit().putBoolean(K_BLUR, v).apply()

    fun lockCard(c: Context): Boolean = sp(c).getBoolean(K_LOCK_CARD, true)
    fun setLockCard(c: Context, v: Boolean) = sp(c).edit().putBoolean(K_LOCK_CARD, v).apply()

    /** Cache em memória: evita reler e copiar o conjunto a cada notificação recebida. */
    @Volatile
    private var appsCache: Set<String>? = null

    fun monitoredApps(c: Context): Set<String> {
        appsCache?.let { return it }
        val stored = sp(c).getStringSet(K_APPS, null)
        val result: Set<String> = if (stored == null) DEFAULT_APPS else HashSet(stored)
        appsCache = result
        return result
    }

    fun setMonitoredApps(c: Context, apps: Set<String>) {
        val copy = HashSet(apps)
        sp(c).edit().putStringSet(K_APPS, copy).apply()
        appsCache = copy
    }
}
