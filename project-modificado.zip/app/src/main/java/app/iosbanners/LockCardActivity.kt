package app.iosbanners

import android.app.Activity
import android.app.KeyguardManager
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.widget.FrameLayout

/**
 * EXPERIMENTAL. Usado quando a notificação chega com a tela apagada: acende a tela bem fraca,
 * sem barras do sistema, com fundo preto puro e só o cartão. Em tela AMOLED o preto fica apagado,
 * então visualmente sobra só a notificação.
 *
 * Isso NÃO é o Always On Display: a tela fica realmente ligada (Activity com setShowWhenLocked +
 * setTurnScreenOn) até o tempo limite de tela do sistema, ou até o limite de segurança abaixo.
 * A posição do cartão é a MESMA do banner da tela ligada ([bannerTopOffset]), sem variação.
 * Como a tela fica fraca e por poucos segundos, o risco de burn-in é desprezível.
 */
class LockCardActivity : Activity() {

    private companion object {
        const val BRIGHTNESS = 0.2f
        // Tela ligada é o maior gasto de bateria deste recurso; 12 s bastam para ler o cartão.
        const val MAX_VISIBLE_MS = 12000L

        // A tela leva um instante para acender; só então a original pode ser removida.
        const val REMOVE_ORIGINAL_DELAY_MS = 700L
    }

    private val handler = Handler(Looper.getMainLooper())
    private val finishRunnable = Runnable { finish() }

    /** Notificações originais aguardando a confirmação de que o cartão está visível. */
    private val pendingOriginalKeys = LinkedHashSet<String>()
    private val removeOriginalRunnable = Runnable {
        val pm = getSystemService(PowerManager::class.java)
        if (!isFinishing && pm?.isInteractive == true) {
            for (key in pendingOriginalKeys) NotificationService.removeOriginalIfEnabled(key)
        }
        pendingOriginalKeys.clear()
    }
    private lateinit var root: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)

        val attrs = window.attributes
        attrs.screenBrightness = BRIGHTNESS
        // A janela sempre começa no topo físico da tela (mesmo com recorte/furo da câmera e
        // barras ocultas), para o cartão ficar na mesma posição do banner da tela ligada.
        attrs.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = attrs

        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        // Toque fora do cartão: fecha e volta ao bloqueio.
        root.setOnClickListener { finish() }
        setContentView(root)
        hideSystemBars()
        render(CardStore.pending)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        render(CardStore.pending)
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            val c = window.insetsController
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars())
                c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
    }

    private fun render(data: CardData?) {
        if (data == null) {
            finish()
            return
        }
        root.removeAllViews()
        val card = NotificationCardView(this)
        card.bind(data, Prefs.darkCard(this), false)
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        // Mesmo alinhamento superior do banner da tela ligada (margem lateral de 8dp igual).
        lp.setMargins(dp(8), bannerTopOffset(), dp(8), 0)
        root.addView(card, lp)

        card.alpha = 0f
        card.translationY = -dp(30).toFloat()
        card.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(380)
            .setInterpolator(PathInterpolator(0.2f, 0.9f, 0.2f, 1f))
            .start()

        card.setOnClickListener { openAfterUnlock(data) }

        // Só depois que o cartão está na tela e a tela realmente acesa, remove a original
        // (evita duplicar sem correr o risco de ficar sem nenhuma das duas).
        pendingOriginalKeys.add(data.key)
        handler.removeCallbacks(removeOriginalRunnable)
        handler.postDelayed(removeOriginalRunnable, REMOVE_ORIGINAL_DELAY_MS)

        handler.removeCallbacks(finishRunnable)
        handler.postDelayed(finishRunnable, MAX_VISIBLE_MS)
    }

    private fun openAfterUnlock(data: CardData) {
        handler.removeCallbacks(finishRunnable)
        val km = getSystemService(KeyguardManager::class.java)
        if (km == null) {
            finish()
            return
        }
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() {
                openSource(applicationContext, data)
                finish()
            }

            override fun onDismissCancelled() {
                finish()
            }

            override fun onDismissError() {
                finish()
            }
        })
    }

    override fun onStop() {
        super.onStop()
        // Quando a tela apaga pelo tempo limite do sistema (ou outro app abre), encerra o cartão.
        if (!isFinishing) finish()
    }

    override fun onDestroy() {
        handler.removeCallbacks(finishRunnable)
        handler.removeCallbacks(removeOriginalRunnable)
        super.onDestroy()
    }
}
